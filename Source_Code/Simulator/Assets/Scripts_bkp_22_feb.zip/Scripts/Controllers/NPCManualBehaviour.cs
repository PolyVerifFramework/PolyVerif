/**
 * Copyright (c) 2020 LG Electronics, Inc.
 *
 * This software contains code licensed as described in LICENSE.
 *
 */

using UnityEngine;
using Simulator.Map;

public class NPCManualBehaviour : NPCBehaviourBase
{
    public override void Init(int seed)
    {
    }

    public override void InitLaneData(MapLane lane)
    {
    }

    public override void OnAgentCollision(GameObject go)
    {
    }

    public override void PhysicsUpdate()
    {
    }
}